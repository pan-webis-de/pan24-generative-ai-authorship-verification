Adapt the pan24-paper.tex to your needs.

If you have formatting questions, check out the formatting-instructions.pdf.

Submit your paper as outlined in the submission-instructions.pdf by 31 May 2024 CEST (!). The instructions also cover the camera-ready submission (Deadline 8 July 2024).

In case of questions, ask the organizers at pan@webis.de.

